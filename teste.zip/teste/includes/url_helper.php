<?php
/**
 * URL Helper Functions
 * Menyediakan fungsi-fungsi untuk mengelola URL secara terpusat
 */

// Pastikan config sudah di-load
if (!defined('BASE_URL')) {
    require_once dirname(__DIR__) . '/config.php';
}

/**
 * Generate URL lengkap dari path relatif
 * @param string $path Path relatif (contoh: 'admin/users' atau 'sheet1.php')
 * @return string URL lengkap
 */
function url($path = '') {
    $path = ltrim($path, '/');
    return BASE_URL . ($path ? '/' . $path : '');
}

/**
 * Generate URL untuk asset (CSS, JS, images)
 * @param string $path Path ke asset
 * @return string URL lengkap ke asset
 */
function asset($path = '') {
    return url($path);
}

/**
 * Redirect ke URL tertentu
 * @param string $path Path tujuan
 * @param int $code HTTP status code (default: 302)
 */
function redirect($path = '', $code = 302) {
    http_response_code($code);
    header('Location: ' . url($path));
    exit;
}

/**
 * Generate URL untuk halaman dengan parameter
 * @param string $page Nama halaman
 * @param array $params Parameter GET
 * @return string URL dengan parameter
 */
function page_url($page, $params = []) {
    $url = url($page);
    if (!empty($params)) {
        $url .= '?' . http_build_query($params);
    }
    return $url;
}

/**
 * Generate URL untuk export dengan parameter filter
 * @param string $export_file Nama file export
 * @param array $filters Filter parameters
 * @return string URL export dengan parameter
 */
function export_url($export_file, $filters = []) {
    return page_url($export_file, $filters);
}

/**
 * Generate URL untuk view dengan parameter
 * @param string $view Nama view
 * @param array $params Parameter
 * @return string URL view
 */
function view_url($view, $params = []) {
    $view_path = 'views/' . $view;
    if (!str_ends_with($view, '.php')) {
        $view_path .= '.php';
    }
    return page_url($view_path, $params);
}

/**
 * Generate URL untuk API endpoint
 * @param string $endpoint API endpoint
 * @param array $params Parameter
 * @return string URL API
 */
function api_url($endpoint, $params = []) {
    $api_path = 'api/' . ltrim($endpoint, '/');
    return page_url($api_path, $params);
}

/**
 * Check apakah URL saat ini sama dengan path yang diberikan
 * @param string $path Path untuk dicek
 * @return bool True jika sama
 */
function is_current_page($path) {
    $current_path = $_SERVER['REQUEST_URI'];
    $check_path = url($path);
    return strpos($current_path, $path) !== false;
}

/**
 * Generate class 'active' jika halaman saat ini
 * @param string $path Path untuk dicek
 * @param string $class Class yang akan dikembalikan jika active
 * @return string Class atau string kosong
 */
function active_class($path, $class = 'active') {
    return is_current_page($path) ? $class : '';
}

/**
 * Generate URL untuk form action
 * @param string $action Action target
 * @return string URL untuk form action
 */
function form_action($action = '') {
    if (empty($action)) {
        return $_SERVER['REQUEST_URI'];
    }
    return url($action);
}

/**
 * Generate URL untuk AJAX request
 * @param string $handler AJAX handler file
 * @param array $params Parameter
 * @return string URL AJAX
 */
function ajax_url($handler, $params = []) {
    $ajax_path = 'ajax/' . ltrim($handler, '/');
    if (!str_ends_with($handler, '.php')) {
        $ajax_path .= '.php';
    }
    return page_url($ajax_path, $params);
}

/**
 * Generate URL untuk download file
 * @param string $file File path
 * @return string URL download
 */
function download_url($file) {
    return url('download.php?file=' . urlencode($file));
}

/**
 * Generate URL dengan hash/anchor
 * @param string $path Path
 * @param string $hash Hash/anchor
 * @param array $params Parameter GET
 * @return string URL dengan hash
 */
function url_with_hash($path, $hash, $params = []) {
    $url = page_url($path, $params);
    return $url . '#' . $hash;
}

/**
 * Get current URL
 * @return string Current URL
 */
function current_url() {
    return url($_SERVER['REQUEST_URI']);
}

/**
 * Get previous URL from referer
 * @param string $default Default URL jika tidak ada referer
 * @return string Previous URL
 */
function previous_url($default = '') {
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    if (empty($referer) || !str_contains($referer, $_SERVER['HTTP_HOST'])) {
        return $default ? url($default) : url();
    }
    return $referer;
}

/**
 * Helper functions untuk file paths
 */

/**
 * Get base path of the application
 * @param string $path Path relatif dari root
 * @return string Full path
 */
function base_path($path = '') {
    $base_dir = dirname(__DIR__); // Parent directory dari includes/
    return $base_dir . ($path ? DIRECTORY_SEPARATOR . $path : '');
}

/**
 * Get path to views directory
 * @param string $path Path relatif dari views/
 * @return string Full path to view file
 */
function views_path($path = '') {
    return base_path('views' . ($path ? DIRECTORY_SEPARATOR . $path : ''));
}

/**
 * Include view file
 * @param string $view View file name
 * @return mixed Include result
 */
function include_view($view) {
    return include views_path($view);
}

/**
 * Check if file exists in base path
 * @param string $path Path relatif dari root
 * @return bool True if file exists
 */
function file_exists_in_base($path) {
    return file_exists(base_path($path));
}

/**
 * Check if view file exists
 * @param string $view View file name
 * @return bool True if view exists
 */
function view_exists($view) {
    return file_exists(views_path($view));
}
?>
