<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'config.php';
require_once 'functions.php';

echo "=== Database Connection Test ===\n";
echo "Connected to: " . $conn->host_info . "\n";
echo "Database: " . $conn->query("SELECT DATABASE()")->fetch_row()[0] . "\n\n";

echo "=== Table Check ===\n";
$result = $conn->query("SHOW TABLES LIKE 'login_logs'");
if ($result && $result->num_rows > 0) {
    echo "✓ login_logs table exists\n";
    
    $columns = $conn->query("DESCRIBE login_logs");
    echo "Table columns:\n";
    while ($col = $columns->fetch_assoc()) {
        echo "- {$col['Field']} ({$col['Type']})\n";
    }
} else {
    echo "✗ login_logs table does not exist\n";
    // Try to create it
    $sql = file_get_contents('sql_create_login_logs.sql');
    if ($conn->multi_query($sql)) {
        echo "✓ Table created successfully\n";
    } else {
        echo "✗ Failed to create table: " . $conn->error . "\n";
    }
}

echo "\n=== Function Test ===\n";
// Test device detection
$device_info = detectDeviceInfo();
echo "Device Info:\n";
print_r($device_info);

echo "\n=== Save Login Log Test ===\n";
$test_result = saveLoginLog('testuser');
echo "Save result: " . ($test_result ? "Success" : "Failed") . "\n";
if (!$test_result) {
    echo "Error: " . $conn->error . "\n";
}

echo "\n=== Data Check ===\n";
$data = $conn->query("SELECT COUNT(*) as count FROM login_logs")->fetch_assoc();
echo "Records in login_logs: " . $data['count'] . "\n";

if ($data['count'] > 0) {
    $logs = $conn->query("SELECT * FROM login_logs ORDER BY waktu_login DESC LIMIT 5");
    echo "Recent logs:\n";
    while ($log = $logs->fetch_assoc()) {
        echo "- {$log['username']} at {$log['waktu_login']} from {$log['ip_address']}\n";
    }
}
?>
