<?php
// Tambahkan filter jurnal di bagian atas laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
?>

<div class="card mb-4">
    <div class="card-header">
        <h6 class="mb-0">Filter Laporan Sheet 3</h6>
    </div>
    <div class="card-body">
        <form method="get" action="index.php" class="row g-3 align-items-center">
            <input type="hidden" name="action" value="sheet3_report">
            <div class="col-md-4">
                <label for="jurnal_filter" class="form-label">Jurnal:</label>
                <select name="jurnal_filter" id="jurnal_filter" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Jurnal</option>
                    <?php foreach ($daftar_jurnal as $id => $nama): ?>
                        <option value="<?= $id ?>" <?= ($selected_jurnal_filter == $id) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($nama) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="tahun_filter" class="form-label">Tahun:</label>
                <select name="tahun_filter" id="tahun_filter" class="form-select" onchange="this.form.submit()">
                    <?php for ($year = date('Y'); $year >= 2020; $year--): ?>
                        <option value="<?= $year ?>" <?= ($selected_tahun_filter == $year) ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label">&nbsp;</label><br>
                <a href="index.php?action=sheet3_report" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise me-1"></i>Reset
                </a>
            </div>
        </form>
    </div>
</div>

<?php
if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    echo "<div class='alert alert-info'>Tidak ada data laporan. Silakan input data terlebih dahulu.</div>";
    return;
}

$report = $_SESSION['sheet3_report'];

// Periksa struktur data yang tersedia
if (!isset($report['bulan']) || !is_array($report['bulan'])) {
    echo "<div class='alert alert-warning'>Struktur data laporan tidak valid.</div>";
    return;
}

// Filter data berdasarkan jurnal yang dipilih
$filtered_categories = [];
$filtered_sub_categories = [];
$filtered_total_kas = [];
$filtered_total_per_kelompok = [];
$filtered_total_per_kategori_bulan = [];

if ($selected_jurnal_filter) {
    // Hanya ambil kategori yang berkaitan dengan jurnal yang dipilih
    if (isset($report['all_categories']) && !empty($report['all_categories'])) {
        foreach ($report['all_categories'] as $kategori) {
            // Cek apakah kategori ini memiliki data untuk jurnal yang dipilih
            $has_data = false;
            foreach ($report['bulan'] as $bulan) {
                $totalKey = $kategori . "|" . $bulan;
                if (isset($report['total_per_kategori_bulan'][$totalKey]) && $report['total_per_kategori_bulan'][$totalKey] > 0) {
                    $has_data = true;
                    break;
                }
            }
            
            if ($has_data) {
                $filtered_categories[] = $kategori;
                if (isset($report['all_sub_categories'][$kategori])) {
                    $filtered_sub_categories[$kategori] = $report['all_sub_categories'][$kategori];
                }
            }
        }
    }
    
    // Filter total_kas hanya untuk kategori yang dipilih
    if (isset($report['total_kas'])) {
        foreach ($report['total_kas'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2 && in_array($parts[0], $filtered_categories)) {
                $filtered_total_kas[$key] = $value;
            }
        }
    }
    
    // Filter total_per_kelompok hanya untuk kategori yang dipilih
    if (isset($report['total_per_kelompok'])) {
        foreach ($report['total_per_kelompok'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2) {
                $kelompok = $parts[0];
                // Cek apakah ada kategori dalam kelompok ini yang termasuk dalam filtered_categories
                $has_kategori_in_kelompok = false;
                foreach ($filtered_categories as $kategori) {
                    if (substr($kategori, 0, 3) === $kelompok) {
                        $has_kategori_in_kelompok = true;
                        break;
                    }
                }
                if ($has_kategori_in_kelompok) {
                    $filtered_total_per_kelompok[$key] = $value;
                }
            }
        }
    }
    
    // Filter total_per_kategori_bulan hanya untuk kategori yang dipilih
    if (isset($report['total_per_kategori_bulan'])) {
        foreach ($report['total_per_kategori_bulan'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2 && in_array($parts[0], $filtered_categories)) {
                $filtered_total_per_kategori_bulan[$key] = $value;
            }
        }
    }
} else {
    // Jika tidak ada filter jurnal, gunakan semua data
    $filtered_categories = $report['all_categories'] ?? [];
    $filtered_sub_categories = $report['all_sub_categories'] ?? [];
    $filtered_total_kas = $report['total_kas'] ?? [];
    $filtered_total_per_kelompok = $report['total_per_kelompok'] ?? [];
    $filtered_total_per_kategori_bulan = $report['total_per_kategori_bulan'] ?? [];
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="bi bi-table me-2"></i>Laporan Horizontal (Sheet 3)
            <?php if ($selected_jurnal_filter): ?>
                <span class="badge bg-primary ms-2"><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></span>
            <?php endif; ?>
            <?php if ($selected_tahun_filter): ?>
                <span class="badge bg-secondary ms-1">Tahun: <?= $selected_tahun_filter ?></span>
            <?php endif; ?>
        </h5>

        <!-- Tombol Export -->
        <?php if (!empty($filtered_categories)): ?>
        <?php
        $export_filters = [
            'jurnal_filter' => $selected_jurnal_filter,
            'tahun_filter' => $selected_tahun_filter
        ];
        ?>
        <div class="d-flex justify-content-end mt-2 gap-2">
            <a href="<?= export_url('sheet3_export.php', $export_filters) ?>"
               class="btn btn-success btn-sm">
                <i class="bi bi-file-earmark-excel me-1"></i> Export Vertikal
            </a>
            <a href="<?= export_url('sheet3_export_horizontal.php', $export_filters) ?>"
               class="btn btn-primary btn-sm">
                <i class="bi bi-file-earmark-spreadsheet me-1"></i> Export Horizontal
            </a>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if (!empty($filtered_categories)): ?>
            <div class="table-responsive" style="overflow-x:auto;">
                <table class="table table-bordered table-hover" id="sheet3Table">
                    <thead class="table-dark">
                        <tr>
                            <th>Kategori</th>
                            <th>Kode Subkategori</th>
                            <th>Uraian</th>
                            <?php foreach ($report['bulan'] as $bulan): ?>
                                <th class="text-center"><?= htmlspecialchars($bulan) ?></th>
                            <?php endforeach; ?>
                            <th class="text-center">Total</th>
                            <th class="text-center">Anggaran Pendapatan</th>
                            <th class="text-center">Selisih</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $current_group = '';
                        $group_totals = array_fill_keys($report['bulan'], 0);
                        $overall_totals = array_fill_keys($report['bulan'], 0);
                        $row_counter = 0;
                        ?>
                        
                        <!-- Tampilkan Uang Setoran terlebih dahulu jika ada -->
                        <?php if (!empty($report['uang_setoran'])): ?>
                            <?php
                            $totalUangSetoran = 0;
                            ?>
                            <tr style="background-color: #c8ffc8;" class="uang-setoran-row" data-row="<?= $row_counter++ ?>">
                                <td>Uang Setoran</td>
                                <td></td>
                                <td></td>
                                <?php foreach ($report['bulan'] as $bulan): 
                                    $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                                    $totalUangSetoran += $amount;
                                    $overall_totals[$bulan] += $amount;
                                ?>
                                    <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($totalUangSetoran, 0, ',', '.') ?></td>
                                <td class="text-center">
                                    <input type="number" class="form-control form-control-sm anggaran-input" 
                                           data-row="<?= $row_counter-1 ?>" 
                                           data-type="uang-setoran" 
                                           placeholder="0" 
                                           step="0.01" 
                                           min="0"
                                           value="<?= isset($report['anggaran_dict']['UANG_SETORAN|All|uang-setoran']) ? 
                                                   $report['anggaran_dict']['UANG_SETORAN|All|uang-setoran'] : '' ?>">
                                </td>
                                <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                    Rp <?= number_format($totalUangSetoran, 0, ',', '.') ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                        
                        <!-- Proses kategori lainnya -->
                        <?php foreach ($filtered_categories as $kategori): ?>
                            <?php
                            // Skip Uang Setoran jika sudah diproses
                            if ($kategori == "Uang Setoran") continue;
                            
                            $kelompok = substr($kategori, 0, 3);
                            
                            // Tampilkan total kelompok jika kelompok berubah
                            if ($kelompok !== $current_group && $current_group !== ''): ?>
                                <tr class="table-warning kelompok-total-row" data-row="<?= $row_counter++ ?>" data-kelompok="<?= $current_group ?>">
                                    <td colspan="2"><strong>Total Kelompok <?= $current_group ?></strong></td>
                                    <td></td>
                                    <?php 
                                    $group_total = 0;
                                    foreach ($report['bulan'] as $bulan): 
                                        $amount = $group_totals[$bulan] ?? 0;
                                        $group_total += $amount;
                                    ?>
                                        <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                    <?php endforeach; ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($group_total, 0, ',', '.') ?></td>
                                    <td class="text-center">
                                        <input type="number" class="form-control form-control-sm anggaran-input" 
                                               data-row="<?= $row_counter-1 ?>" 
                                               data-type="kelompok" 
                                               data-kelompok="<?= $current_group ?>"
                                               placeholder="0" 
                                               step="0.01" 
                                               min="0"
                                               value="<?= isset($report['anggaran_dict'][$current_group . '|All|kelompok']) ? 
                                                       $report['anggaran_dict'][$current_group . '|All|kelompok'] : '' ?>">
                                    </td>
                                    <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                        Rp <?= number_format($group_total, 0, ',', '.') ?>
                                    </td>
                                </tr>
                                <?php 
                                // Reset group totals
                                $group_totals = array_fill_keys($report['bulan'], 0);
                            endif;
                            
                            $current_group = $kelompok;
                            $hasDataInCategory = false;
                            ?>
                            
                            <!-- Tampilkan subkategori dalam kategori ini -->
                            <?php if (isset($filtered_sub_categories[$kategori])): ?>
                                <?php foreach ($filtered_sub_categories[$kategori] as $subkategori): ?>
                                    <?php
                                    $hasData = false;
                                    $sub_total = 0;
                                    
                                    // Cek apakah ada data untuk subkategori ini
                                    foreach ($report['bulan'] as $bulan) {
                                        $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                        if (isset($filtered_total_kas[$uniqueKey]) && $filtered_total_kas[$uniqueKey] > 0) {
                                            $hasData = true;
                                            break;
                                        }
                                    }
                                    
                                    if (!$hasData) continue;
                                    $hasDataInCategory = true;
                                    ?>
                                    
                                    <tr class="subkategori-row" data-row="<?= $row_counter++ ?>" data-kategori="<?= $kategori ?>" data-subkategori="<?= $subkategori ?>">
                                        <td><?= htmlspecialchars($kategori) ?></td>
                                        <td><?= htmlspecialchars($subkategori) ?></td>
                                        <td><?= isset($report['uraian_dict'][$subkategori]) ? htmlspecialchars($report['uraian_dict'][$subkategori]) : 'Uraian Tidak Diketahui' ?></td>
                                        <?php 
                                        $sub_total = 0;
                                        foreach ($report['bulan'] as $bulan): 
                                            $uniqueKey = $kategori . "|" . $subkategori . "|" . $bulan;
                                            $amount = isset($filtered_total_kas[$uniqueKey]) ? $filtered_total_kas[$uniqueKey] : 0;
                                            $sub_total += $amount;
                                            $group_totals[$bulan] += $amount;
                                            $overall_totals[$bulan] += $amount;
                                        ?>
                                            <td class="text-end">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                        <?php endforeach; ?>
                                        <td class="text-end fw-bold">Rp <?= number_format($sub_total, 0, ',', '.') ?></td>
                                        <td class="text-center">
                                            <input type="number" class="form-control form-control-sm anggaran-input" 
                                                   data-row="<?= $row_counter-1 ?>" 
                                                   data-type="subkategori" 
                                                   data-kategori="<?= $kategori ?>" 
                                                   data-subkategori="<?= $subkategori ?>"
                                                   placeholder="0" 
                                                   step="0.01" 
                                                   min="0"
                                                   value="<?= isset($report['anggaran_dict'][$subkategori . '|All|subkategori']) ? 
                                                           $report['anggaran_dict'][$subkategori . '|All|subkategori'] : '' ?>">
                                        </td>
                                        <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                            Rp <?= number_format($sub_total, 0, ',', '.') ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            
                        <?php endforeach; ?>
                        
                        <!-- Total kelompok terakhir -->
                        <?php if ($current_group !== ''): ?>
                            <tr class="table-warning kelompok-total-row" data-row="<?= $row_counter++ ?>" data-kelompok="<?= $current_group ?>">
                                <td colspan="2"><strong>Total Kelompok <?= $current_group ?></strong></td>
                                <td></td>
                                <?php 
                                $group_total = 0;
                                foreach ($report['bulan'] as $bulan): 
                                    $amount = $group_totals[$bulan] ?? 0;
                                    $group_total += $amount;
                                ?>
                                    <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                                <?php endforeach; ?>
                                <td class="text-end fw-bold">Rp <?= number_format($group_total, 0, ',', '.') ?></td>
                                <td class="text-center">
                                    <input type="number" class="form-control form-control-sm anggaran-input" 
                                           data-row="<?= $row_counter-1 ?>" 
                                           data-type="kelompok" 
                                           data-kelompok="<?= $current_group ?>"
                                           placeholder="0" 
                                           step="0.01" 
                                           min="0"
                                           value="<?= isset($report['anggaran_dict'][$current_group . '|All|kelompok']) ? 
                                                   $report['anggaran_dict'][$current_group . '|All|kelompok'] : '' ?>">
                                </td>
                                <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                    Rp <?= number_format($group_total, 0, ',', '.') ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                        
                        <!-- Total keseluruhan -->
                        <tr class="table-primary total-keseluruhan-row" data-row="<?= $row_counter++ ?>">
                            <td colspan="2"><strong>TOTAL KESELURUHAN</strong></td>
                            <td></td>
                            <?php 
                            $grand_total = 0;
                            foreach ($report['bulan'] as $bulan): 
                                $amount = $overall_totals[$bulan] ?? 0;
                                $grand_total += $amount;
                            ?>
                                <td class="text-end fw-bold">Rp <?= number_format($amount, 0, ',', '.') ?></td>
                            <?php endforeach; ?>
                            <td class="text-end fw-bold">Rp <?= number_format($grand_total, 0, ',', '.') ?></td>
                            <td class="text-center">
                                <input type="number" class="form-control form-control-sm anggaran-input" 
                                       data-row="<?= $row_counter-1 ?>" 
                                       data-type="keseluruhan" 
                                       placeholder="0" 
                                       step="0.01" 
                                       min="0"
                                       value="<?= isset($report['anggaran_dict']['TOTAL_KESELURUHAN|All|keseluruhan']) ? 
                                               $report['anggaran_dict']['TOTAL_KESELURUHAN|All|keseluruhan'] : '' ?>">
                            </td>
                            <td class="text-end fw-bold selisih-cell" data-row="<?= $row_counter-1 ?>">
                                Rp <?= number_format($grand_total, 0, ',', '.') ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                Tidak ada data kategori yang tersedia untuk jurnal yang dipilih.
            </div>
        <?php endif; ?>
    </div>


</div>

<!-- JavaScript untuk perhitungan selisih dan input anggaran -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Fungsi untuk format angka ke format rupiah
    function formatRupiah(angka) {
        return 'Rp ' + new Intl.NumberFormat('id-ID').format(angka);
    }
    
    // Fungsi untuk menghitung selisih
    function hitungSelisih(row) {
        const totalCell = row.querySelector('td:nth-last-child(3)'); // Kolom Total
        const anggaranInput = row.querySelector('.anggaran-input');
        const selisihCell = row.querySelector('.selisih-cell');

        if (totalCell && anggaranInput && selisihCell) {
            const totalText = totalCell.textContent.replace(/[^\d]/g, '');
            const total = parseFloat(totalText) || 0;
            const anggaran = parseFloat(anggaranInput.value) || 0;
            const selisih = anggaran - total; // Rumus: anggaran - total

            selisihCell.textContent = formatRupiah(selisih);

            // Tambahkan warna berdasarkan selisih
            if (selisih > 0) {
                selisihCell.className = 'text-end fw-bold text-success'; // Anggaran lebih besar (surplus)
            } else if (selisih < 0) {
                selisihCell.className = 'text-end fw-bold text-danger'; // Anggaran lebih kecil (defisit)
            } else {
                selisihCell.className = 'text-end fw-bold text-primary'; // Seimbang
            }
        }
    }
    
    // Fungsi untuk menyimpan anggaran ke database
    function simpanAnggaranKeDatabase(data) {
        fetch('api/save_anggaran.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            if (!data.success) {
                console.error('Gagal menyimpan anggaran:', data.message);
                showNotification('Gagal menyimpan anggaran: ' + data.message, 'error');
            } else {
                console.log('Anggaran berhasil disimpan');
                showNotification('Anggaran berhasil disimpan', 'success');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showNotification('Terjadi kesalahan saat menyimpan: ' + error.message, 'error');
        });
    }

    // Fungsi untuk menampilkan notifikasi
    function showNotification(message, type = 'info') {
        // Buat elemen notifikasi
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; right: 20px; z-index: 1050; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Hapus otomatis setelah 3 detik
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    
    // Event listener untuk input anggaran
    document.addEventListener('input', function(e) {
        if (e.target.classList.contains('anggaran-input')) {
            const row = e.target.closest('tr');
            hitungSelisih(row);
            
            // Ambil data untuk disimpan
            const type = e.target.dataset.type;
            let kode_subkategori = '';
            const bulan = 'All'; // Atau bisa disesuaikan dengan bulan tertentu
            
            switch (type) {
                case 'subkategori':
                    kode_subkategori = e.target.dataset.subkategori || '';
                    break;
                case 'kelompok':
                    kode_subkategori = e.target.dataset.kelompok || '';
                    break;
                case 'uang-setoran':
                    kode_subkategori = 'UANG_SETORAN';
                    break;
                case 'keseluruhan':
                    kode_subkategori = 'TOTAL_KESELURUHAN';
                    break;
            }
            
            const jumlah = parseFloat(e.target.value) || 0;
            
            // Simpan ke database
            simpanAnggaranKeDatabase({
                type: type,
                kode_subkategori: kode_subkategori,
                bulan: bulan,
                jumlah: jumlah
            });
        }
    });
    
    // Event listener untuk double click (reset)
    document.addEventListener('dblclick', function(e) {
        if (e.target.classList.contains('anggaran-input')) {
            if (confirm('Apakah Anda yakin ingin menghapus nilai anggaran ini?')) {
                e.target.value = '';
                hitungSelisih(e.target.closest('tr'));
                
                // Hapus dari database juga
                const type = e.target.dataset.type;
                let kode_subkategori = '';
                const bulan = 'All';
                
                switch (type) {
                    case 'subkategori':
                        kode_subkategori = e.target.dataset.subkategori || '';
                        break;
                    case 'kelompok':
                        kode_subkategori = e.target.dataset.kelompok || '';
                        break;
                    case 'uang-setoran':
                        kode_subkategori = 'UANG_SETORAN';
                        break;
                    case 'keseluruhan':
                        kode_subkategori = 'TOTAL_KESELURUHAN';
                        break;
                }
                
                simpanAnggaranKeDatabase({
                    type: type,
                    kode_subkategori: kode_subkategori,
                    bulan: bulan,
                    jumlah: 0
                });
            }
        }
    });
    
    // Inisialisasi perhitungan selisih untuk semua baris
    document.querySelectorAll('tr[data-row]').forEach(function(row) {
        hitungSelisih(row);
    });
    
    // Tambahkan tooltip untuk instruksi
    const anggaranInputs = document.querySelectorAll('.anggaran-input');
    anggaranInputs.forEach(function(input) {
        input.title = 'Klik untuk input anggaran, Double click untuk hapus';
    });
});
</script>

<style>
.anggaran-input {
    width: 100px;
    text-align: center;
    font-size: 0.875rem;
}

.anggaran-input:focus {
    border-color: #007bff;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.selisih-cell.text-success {
    color: #28a745 !important;
}

.selisih-cell.text-danger {
    color: #dc3545 !important;
}

.selisih-cell.text-primary {
    color: #007bff !important;
}

/* Hover effect untuk input anggaran */
.anggaran-input:hover {
    background-color: #f8f9fa;
}

/* Responsive table */
@media (max-width: 768px) {
    .anggaran-input {
        width: 80px;
        font-size: 0.8rem;
    }
}

/* CSS untuk notifikasi */
.alert-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 1050;
    min-width: 300px;
    animation: slideIn 0.3s ease-out;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}
</style>