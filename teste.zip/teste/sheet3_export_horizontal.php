<?php
session_start();

// Ambil parameter filter yang sama dengan laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');

// Validasi session dan data
if (!isset($_SESSION['sheet3_report']) || empty($_SESSION['sheet3_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet3_report'];
$daftar_jurnal = isset($_SESSION['daftar_jurnal']) ? $_SESSION['daftar_jurnal'] : [];

// Ambil data anggaran dari session
$anggaran_dict = isset($report['anggaran_dict']) ? $report['anggaran_dict'] : [];

// Filter data berdasarkan jurnal yang dipilih
$filtered_categories = [];
$filtered_sub_categories = [];
$filtered_total_kas = [];
$filtered_total_per_kelompok = [];
$filtered_total_per_kategori_bulan = [];
$filtered_anggaran_dict = [];

if ($selected_jurnal_filter) {
    // Hanya ambil kategori yang berkaitan dengan jurnal yang dipilih
    if (isset($report['all_categories']) && !empty($report['all_categories'])) {
        foreach ($report['all_categories'] as $kategori) {
            // Cek apakah kategori ini memiliki data untuk jurnal yang dipilih
            $has_data = false;
            foreach ($report['bulan'] as $bulan) {
                $totalKey = $kategori . "|" . $bulan;
                if (isset($report['total_per_kategori_bulan'][$totalKey]) && $report['total_per_kategori_bulan'][$totalKey] > 0) {
                    $has_data = true;
                    break;
                }
            }

            if ($has_data) {
                $filtered_categories[] = $kategori;
                if (isset($report['all_sub_categories'][$kategori])) {
                    $filtered_sub_categories[$kategori] = $report['all_sub_categories'][$kategori];
                }
            }
        }
    }

    // Filter total_kas hanya untuk kategori yang dipilih
    if (isset($report['total_kas'])) {
        foreach ($report['total_kas'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2 && in_array($parts[0], $filtered_categories)) {
                $filtered_total_kas[$key] = $value;
            }
        }
    }

    // Filter total_per_kelompok hanya untuk kategori yang dipilih
    if (isset($report['total_per_kelompok'])) {
        foreach ($report['total_per_kelompok'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2) {
                $kelompok = $parts[0];
                // Cek apakah ada kategori dalam kelompok ini yang termasuk dalam filtered_categories
                $has_kategori_in_kelompok = false;
                foreach ($filtered_categories as $kategori) {
                    if (substr($kategori, 0, 3) === $kelompok) {
                        $has_kategori_in_kelompok = true;
                        break;
                    }
                }
                if ($has_kategori_in_kelompok) {
                    $filtered_total_per_kelompok[$key] = $value;
                }
            }
        }
    }

    // Filter total_per_kategori_bulan hanya untuk kategori yang dipilih
    if (isset($report['total_per_kategori_bulan'])) {
        foreach ($report['total_per_kategori_bulan'] as $key => $value) {
            $parts = explode('|', $key);
            if (count($parts) >= 2 && in_array($parts[0], $filtered_categories)) {
                $filtered_total_per_kategori_bulan[$key] = $value;
            }
        }
    }
} else {
    // Jika tidak ada filter jurnal, gunakan semua data
    $filtered_categories = $report['all_categories'] ?? [];
    $filtered_sub_categories = $report['all_sub_categories'] ?? [];
    $filtered_total_kas = $report['total_kas'] ?? [];
    $filtered_total_per_kelompok = $report['total_per_kelompok'] ?? [];
    $filtered_total_per_kategori_bulan = $report['total_per_kategori_bulan'] ?? [];
}

// Anggaran tidak difilter berdasarkan jurnal karena anggaran berlaku untuk semua jurnal
$filtered_anggaran_dict = $anggaran_dict;

// Set header untuk download file Excel
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Laporan_Sheet3_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .title { font-size: 18pt; font-weight: bold; color: #1F4E78; margin-bottom: 5px; }
        .subtitle { font-size: 14pt; color: #2F75B5; margin-bottom: 15px; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .info-table td { padding: 5px; border: 1px solid #BFBFBF; }
        .info-label { font-weight: bold; background-color: #E6E6E6; width: 120px; }
        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .data-table th { background-color: #4472C4; color: white; font-weight: bold; padding: 8px; border: 1px solid #5B5B5B; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #BFBFBF; vertical-align: top; }
        .total-row { font-weight: bold; background-color: #D9E1F2; }
        .kelompok-row { background-color: #FFF3CD; font-weight: bold; }
        .keseluruhan-row { background-color: #CCE5FF; font-weight: bold; }
        .uang-setoran-row { background-color: #C8FFC8; font-weight: bold; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .number-format { mso-number-format: "#\\.##0"; }
        .negative-number { color: #DC3545; font-weight: bold; }
        .footer { margin-top: 30px; font-style: italic; color: #7F7F7F; text-align: right; }
        /* Add horizontal scroll for tables */
        .data-table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN HORIZONTAL</div>
        <div class="subtitle">SHEET 3 - REKAPITULASI PER BULAN</div>
    </div>

    <table class="info-table">
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
        <tr>
            <td class="info-label">Jurnal:</td>
            <td><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($selected_tahun_filter): ?>
        <tr>
            <td class="info-label">Tahun:</td>
            <td><?= $selected_tahun_filter ?></td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="info-label">Tanggal Export:</td>
            <td><?= date('d-m-Y H:i:s') ?></td>
        </tr>
    </table>

    <?php if (!empty($filtered_categories)): ?>
        <div class="data-table-wrapper">
        <table class="data-table">
            <thead>
                <tr>
                    <th>Kode Kategori</th>
                    <th>Subkode</th>
                    <th>KEGIATAN (Level 1)</th>
                    <th>Kode Detail</th>
                    <th>URAIAN KEGIATAN (Level 2)</th>
                    <?php foreach ($report['bulan'] as $bulan): ?>
                        <th><?= htmlspecialchars($bulan) ?></th>
                    <?php endforeach; ?>
                    <th>Total</th>
                    <th>Anggaran Pendapatan</th>
                    <th>Selisih</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $group_totals = array_fill_keys($report['bulan'], 0);
                $overall_totals = array_fill_keys($report['bulan'], 0);
                $row_counter = 0;

                // Bangun peta: kat3 => [kat6...], dan kat6 => [detail...]
                $map_kat3_to_kat6 = [];
                $map_kat6_to_details = [];
                foreach ($filtered_sub_categories as $kat6 => $subsFull) {
                    $kat3 = substr($kat6, 0, 3);
                    if (!isset($map_kat3_to_kat6[$kat3])) $map_kat3_to_kat6[$kat3] = [];
                    if (!in_array($kat6, $map_kat3_to_kat6[$kat3])) $map_kat3_to_kat6[$kat3][] = $kat6;
                    foreach ($subsFull as $codeFull) {
                        $parts = explode('.', $codeFull);
                        if (count($parts) >= 3) {
                            if (!isset($map_kat6_to_details[$kat6])) $map_kat6_to_details[$kat6] = [];
                            if (!in_array($codeFull, $map_kat6_to_details[$kat6])) $map_kat6_to_details[$kat6][] = $codeFull;
                        }
                    }
                }

                // Helper: sum untuk sekumpulan key
                $get_total_for_keys = function($keys, $bulan) use ($filtered_total_kas) {
                    $sum = 0;
                    foreach ($keys as $k) {
                        $sum += isset($filtered_total_kas[$k]) ? $filtered_total_kas[$k] : 0;
                    }
                    return $sum;
                };

                // Helper: ambil anggaran berdasarkan kode dan type
                $get_anggaran = function($kode, $type) use ($filtered_anggaran_dict) {
                    $key = $kode . '|All|' . $type;
                    return isset($filtered_anggaran_dict[$key]) ? (float)$filtered_anggaran_dict[$key] : 0;
                };

                // Helper: format selisih dengan kurung untuk minus dan warna merah
                $format_selisih = function($selisih) {
                    if ($selisih < 0) {
                        $abs_selisih = abs($selisih);
                        return '<span class="negative-number">(' . number_format($abs_selisih, 0, '', '') . ')</span>';
                    } else {
                        return number_format($selisih, 0, '', '');
                    }
                };
                ?>

                <!-- Uang Setoran di awal jika ada -->
                <?php if (!empty($report['uang_setoran'])): ?>
                    <?php
                    $totalUangSetoran = 0;
                    foreach ($report['bulan'] as $bulan) {
                        $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                        $totalUangSetoran += $amount;
                        $overall_totals[$bulan] += $amount;
                    }
                    $anggaranUangSetoran = $get_anggaran('UANG_SETORAN', 'uang-setoran');
                    $selisihUangSetoran = $anggaranUangSetoran - $totalUangSetoran;
                    ?>
                    <tr class="uang-setoran-row">
                        <td>Uang Setoran</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <?php foreach ($report['bulan'] as $bulan):
                            $amount = isset($report['uang_setoran'][$bulan]) ? $report['uang_setoran'][$bulan] : 0;
                        ?>
                            <td class="text-right number-format"><?= number_format($amount, 0, '', '') ?></td>
                        <?php endforeach; ?>
                        <td class="text-right number-format"><?= number_format($totalUangSetoran, 0, '', '') ?></td>
                        <td class="text-right number-format"><?= $anggaranUangSetoran > 0 ? number_format($anggaranUangSetoran, 0, '', '') : '0' ?></td>
                        <td class="text-right number-format"><?= number_format($selisihUangSetoran, 0, '', '') ?></td>
                    </tr>
                <?php endif; ?>
                <?php
                $kat3_list = array_keys($map_kat3_to_kat6);
                sort($kat3_list);
                foreach ($kat3_list as $kat3):
                    $kat6_list = $map_kat3_to_kat6[$kat3];
                    sort($kat6_list);

                    // Precompute total per bulan untuk kategori 3-digit
                    $kategori_total_per_bulan = array_fill_keys($report['bulan'], 0);
                    $sub_rows = [];
                    foreach ($kat6_list as $kat6) {
                        $subcode2 = substr($kat6, 4, 2);
                        $detail_list = isset($map_kat6_to_details[$kat6]) ? $map_kat6_to_details[$kat6] : [];

                        $sub_sums = [];
                        $sub_total_all = 0;
                        foreach ($report['bulan'] as $bulan) {
                            $keys = [];
                            $keys[] = $kat6.'|'.$kat6.'|'.$bulan; // level 6 langsung
                            foreach ($detail_list as $dfull) {
                                $keys[] = $kat6.'|'.$dfull.'|'.$bulan; // level detail
                            }
                            $val = $get_total_for_keys($keys, $bulan);
                            $sub_sums[$bulan] = $val;
                            $sub_total_all += $val;
                            $kategori_total_per_bulan[$bulan] += $val;
                        }

                        // Simpan untuk render
                        $sub_rows[] = [
                            'kat6' => $kat6,
                            'subcode2' => $subcode2,
                            'detail_list' => $detail_list,
                            'sums' => $sub_sums,
                            'total' => $sub_total_all,
                        ];
                    }

                    // Render baris kategori 3-digit
                    $kategori_total_all = 0;
                    foreach ($report['bulan'] as $bulan) {
                        $amount = $kategori_total_per_bulan[$bulan] ?? 0;
                        $kategori_total_all += $amount;
                    }
                    $anggaranKat3 = $get_anggaran($kat3, 'kelompok');
                    $selisihKat3 = $anggaranKat3 - $kategori_total_all;
                    ?>
                    <tr>
                        <td class="fw-bold"><?= htmlspecialchars($kat3) ?></td>
                        <td class="fw-bold"></td>
                        <td class="fw-bold"><?= isset($report['uraian_dict'][$kat3]) ? htmlspecialchars($report['uraian_dict'][$kat3]) : '' ?></td>
                        <td class="fw-bold"></td>
                        <td class="fw-bold"></td>
                        <?php foreach ($report['bulan'] as $bulan):
                            $amount = $kategori_total_per_bulan[$bulan] ?? 0;
                        ?>
                            <td class="text-right number-format"><?= number_format($amount, 0, '', '') ?></td>
                        <?php endforeach; ?>
                        <td class="text-right number-format"><?= number_format($kategori_total_all, 0, '', '') ?></td>
                        <td class="text-right number-format"><?= $anggaranKat3 > 0 ? number_format($anggaranKat3, 0, '', '') : '0' ?></td>
                        <td class="text-right number-format"><?= number_format($selisihKat3, 0, '', '') ?></td>
                    </tr>

                    <?php
                    // Render sub 6-digit dan detail di bawahnya
                    foreach ($sub_rows as $sr):
                        if ($sr['total'] <= 0) continue;
                        $kat6 = $sr['kat6'];
                        $subcode2 = $sr['subcode2'];
                        $detail_list = $sr['detail_list'];
                    ?>
                        <?php
                        $anggaranKat6 = $get_anggaran($kat6, 'subkategori');
                        $selisihKat6 = $anggaranKat6 - $sr['total'];
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($kat3) ?></td>
                            <td><?= htmlspecialchars($subcode2) ?></td>
                            <td><?= isset($report['uraian_dict'][$kat3]) ? htmlspecialchars($report['uraian_dict'][$kat3]) : '' ?></td>
                            <td></td>
                            <td><?= isset($report['uraian_dict'][$kat6]) ? htmlspecialchars($report['uraian_dict'][$kat6]) : 'Uraian Tidak Diketahui' ?></td>
                            <?php foreach ($report['bulan'] as $bulan):
                                $amount = $sr['sums'][$bulan] ?? 0;
                                $group_totals[$bulan] += $amount;
                                $overall_totals[$bulan] += $amount;
                            ?>
                                <td class="text-right number-format"><?= number_format($amount, 0, '', '') ?></td>
                            <?php endforeach; ?>
                            <td class="text-right number-format"><?= number_format($sr['total'], 0, '', '') ?></td>
                            <td class="text-right number-format"><?= $anggaranKat6 > 0 ? number_format($anggaranKat6, 0, '', '') : '0' ?></td>
                            <td class="text-right number-format"><?= number_format($selisihKat6, 0, '', '') ?></td>
                        </tr>

                        <?php
                        // Render detail
                        sort($detail_list);
                        foreach ($detail_list as $dfull):
                            $parts = explode('.', $dfull);
                            $detail_code = $parts[2] ?? '';
                            $detail_total = 0;
                        ?>
                            <?php
                            $anggaranDetail = $get_anggaran($dfull, 'subkategori');
                            $selisihDetail = $anggaranDetail - $detail_total;
                            ?>
                            <tr>
                                <td><?= htmlspecialchars($kat3) ?></td>
                                <td><?= htmlspecialchars($subcode2) ?></td>
                                <td><?= isset($report['uraian_dict'][$kat3]) ? htmlspecialchars($report['uraian_dict'][$kat3]) : '' ?></td>
                                <td><?= htmlspecialchars($detail_code) ?></td>
                                <td><?= isset($report['uraian_dict'][$dfull]) ? htmlspecialchars($report['uraian_dict'][$dfull]) : (isset($report['uraian_dict'][$kat6]) ? htmlspecialchars($report['uraian_dict'][$kat6]) : 'Uraian Tidak Diketahui') ?></td>
                                <?php foreach ($report['bulan'] as $bulan):
                                    $key = $kat6.'|'.$dfull.'|'.$bulan;
                                    $amount = isset($filtered_total_kas[$key]) ? $filtered_total_kas[$key] : 0;
                                    $detail_total += $amount;
                                ?>
                                    <td class="text-right number-format"><?= number_format($amount, 0, '', '') ?></td>
                                <?php endforeach; ?>
                                <td class="text-right number-format"><?= number_format($detail_total, 0, '', '') ?></td>
                                <td class="text-right number-format"><?= $anggaranDetail > 0 ? number_format($anggaranDetail, 0, '', '') : '0' ?></td>
                                <td class="text-right number-format"><?= number_format($selisihDetail, 0, '', '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; // sub_rows ?>

                    <?php
                    // Total per kelompok (3 digit), gunakan akumulasi group_totals saat ini
                    $group_total_all = 0;
                    foreach ($report['bulan'] as $bulan) {
                        $amount = $group_totals[$bulan] ?? 0;
                        $group_total_all += $amount;
                    }
                    $anggaranKelompok = $get_anggaran($kat3, 'kelompok');
                    $selisihKelompok = $anggaranKelompok - $group_total_all;
                    ?>
                    <tr class="kelompok-row">
                        <td colspan="5"><strong>Total Kelompok <?= $kat3 ?></strong></td>
                        <?php foreach ($report['bulan'] as $bulan):
                            $amount = $group_totals[$bulan] ?? 0;
                        ?>
                            <td class="text-right number-format"><?= number_format($amount, 0, '', '') ?></td>
                        <?php endforeach; ?>
                        <td class="text-right number-format"><?= number_format($group_total_all, 0, '', '') ?></td>
                        <td class="text-right number-format"><?= $anggaranKelompok > 0 ? number_format($anggaranKelompok, 0, '', '') : '0' ?></td>
                        <td class="text-right number-format"><?= number_format($selisihKelompok, 0, '', '') ?></td>
                    </tr>
                    <?php $group_totals = array_fill_keys($report['bulan'], 0); // reset untuk kelompok berikutnya ?>
                <?php endforeach; // kat3 ?>
                <!-- Total keseluruhan -->
                <?php
                $grand_total = 0;
                foreach ($report['bulan'] as $bulan) {
                    $amount = $overall_totals[$bulan] ?? 0;
                    $grand_total += $amount;
                }
                $anggaranKeseluruhan = $get_anggaran('TOTAL_KESELURUHAN', 'keseluruhan');
                $selisihKeseluruhan = $anggaranKeseluruhan - $grand_total;
                ?>
                <tr class="keseluruhan-row">
                    <td colspan="5"><strong>TOTAL KESELURUHAN</strong></td>
                    <?php foreach ($report['bulan'] as $bulan):
                        $amount = $overall_totals[$bulan] ?? 0;
                    ?>
                        <td class="text-right number-format"><?= number_format($amount, 0, '', '') ?></td>
                    <?php endforeach; ?>
                    <td class="text-right number-format"><?= number_format($grand_total, 0, '', '') ?></td>
                    <td class="text-right number-format"><?= $anggaranKeseluruhan > 0 ? number_format($anggaranKeseluruhan, 0, '', '') : '0' ?></td>
                    <td class="text-right number-format"><?= number_format($selisihKeseluruhan, 0, '', '') ?></td>
                </tr>
            </tbody>
        </table>
        </div>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; font-style: italic; text-align: center; margin: 30px 0;">
            Tidak ada data yang cocok dengan filter yang dipilih.
        </div>
    <?php endif; ?>

    <div class="footer">
        Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan
    </div>
</body>
</html>
