<?php
// Tambahkan filter jurnal di bagian atas laporan
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
?>

<div class="card mb-4">
    <div class="card-header">
        <h6 class="mb-0">Filter Laporan Sheet 2</h6>
    </div>
    <div class="card-body">
        <form method="get" action="index.php" class="row g-3 align-items-center">
            <input type="hidden" name="action" value="sheet2_report">
            <div class="col-md-3">
                <label for="jurnal_filter" class="form-label">Jurnal:</label>
                <select name="jurnal_filter" id="jurnal_filter" class="form-select" onchange="this.form.submit()">
                    <option value="">Semua Jurnal</option>
                    <?php foreach ($daftar_jurnal as $id => $nama): ?>
                        <option value="<?= $id ?>" <?= ($selected_jurnal_filter == $id) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($nama) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label for="tahun_filter" class="form-label">Tahun:</label>
                <select name="tahun_filter" id="tahun_filter" class="form-select" onchange="this.form.submit()">
                    <?php for ($year = date('Y'); $year >= 2020; $year--): ?>
                        <option value="<?= $year ?>" <?= ($selected_tahun_filter == $year) ? 'selected' : '' ?>>
                            <?= $year ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="search" class="form-label">Pencarian:</label>
                <div class="input-group">
                    <input type="text" 
                           name="search" 
                           id="search" 
                           class="form-control" 
                           value="<?= htmlspecialchars($search_keyword) ?>" 
                           placeholder="Cari nomor kwitansi atau uraian...">
                    <button type="submit" class="btn btn-primary">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label">&nbsp;</label><br>
                <a href="index.php?action=sheet2_report" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-clockwise me-1"></i>Reset
                </a>
            </div>
        </form>
    </div>
</div>

<?php
if (!isset($_SESSION['sheet2_report']) || empty($_SESSION['sheet2_report'])) {
    echo "<div class='alert alert-info'>Tidak ada data laporan. Silakan input data terlebih dahulu.</div>";
    return;
}

$report = $_SESSION['sheet2_report'];

// Filter data berdasarkan jurnal yang dipilih
if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])) {
    $selected_jurnal_name = $daftar_jurnal[$selected_jurnal_filter];
    // Hanya tampilkan data untuk jurnal yang dipilih
    if (isset($report[$selected_jurnal_name])) {
        $filtered_report = [$selected_jurnal_name => $report[$selected_jurnal_name]];
        $report = $filtered_report;
    } else {
        echo "<div class='alert alert-warning'>Tidak ada data untuk jurnal yang dipilih.</div>";
        $report = [];
    }
}

// Filter berdasarkan keyword pencarian
if (!empty($search_keyword)) {
    $filtered_report = [];
    
    foreach ($report as $jurnal => $bulan_data) {
        $filtered_bulan_data = [];
        
        foreach ($bulan_data as $bulan => $subkategori_data) {
            $filtered_subkategori_data = [];
            
            foreach ($subkategori_data as $subkategori => $data) {
                $filtered_transactions = [];
                
                foreach ($data['transactions'] as $trans) {
                    // Cari berdasarkan nomor kwitansi atau uraian
                    if (stripos($trans['no_kwitansi'], $search_keyword) !== false || 
                        stripos($trans['uraian'], $search_keyword) !== false) {
                        $filtered_transactions[] = $trans;
                    }
                }
                
                // Hanya tampilkan jika ada transaksi yang cocok
                if (!empty($filtered_transactions)) {
                    $filtered_subkategori_data[$subkategori] = [
                        'kategori' => $data['kategori'],
                        'transactions' => $filtered_transactions,
                        'total' => array_sum(array_column($filtered_transactions, 'jumlah'))
                    ];
                }
            }
            
            // Hanya tampilkan bulan jika ada subkategori yang cocok
            if (!empty($filtered_subkategori_data)) {
                $filtered_bulan_data[$bulan] = $filtered_subkategori_data;
            }
        }
        
        // Hanya tampilkan jurnal jika ada bulan yang cocok
        if (!empty($filtered_bulan_data)) {
            $filtered_report[$jurnal] = $filtered_bulan_data;
        }
    }
    
    $report = $filtered_report;
}
?>

<div class="card">
    <div class="card-header">
        <h5 class="card-title mb-0">
            <i class="bi bi-list-check me-2"></i>Laporan Terstruktur (Sheet 2)
            <?php if ($selected_jurnal_filter): ?>
                <span class="badge bg-primary ms-2"><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></span>
            <?php endif; ?>
            <?php if ($selected_tahun_filter): ?>
                <span class="badge bg-secondary ms-1">Tahun: <?= $selected_tahun_filter ?></span>
            <?php endif; ?>
            <?php if ($search_keyword): ?>
                <span class="badge bg-info ms-1">Pencarian: "<?= htmlspecialchars($search_keyword) ?>"</span>
            <?php endif; ?>
        </h5>

        <!-- Tombol Export -->
        <?php if (!empty($report)): ?>
        <?php
        $export_filters = [
            'jurnal_filter' => $selected_jurnal_filter,
            'tahun_filter' => $selected_tahun_filter,
            'search' => $search_keyword
        ];
        ?>
        <div class="d-flex justify-content-end mt-2 gap-2">
            <a href="<?= export_url('sheet2_export_structured.php', $export_filters) ?>"
               class="btn btn-success btn-sm">
                <i class="bi bi-file-earmark-excel me-1"></i> Export Vertikal
            </a>
            <a href="<?= export_url('sheet2_export_horizontal.php', $export_filters) ?>"
               class="btn btn-primary btn-sm">
                <i class="bi bi-file-earmark-spreadsheet me-1"></i> Export Horizontal
            </a>
        </div>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <?php if (!empty($report)): ?>
            <?php foreach ($report as $jurnal => $bulan_data): ?>
                <h4 class="text-primary mb-3">Jurnal: <?= htmlspecialchars($jurnal) ?></h4>
                
                <?php foreach ($bulan_data as $bulan => $subkategori_data): ?>
                    <div class="mb-4">
                        <h5 class="text-secondary mb-3"><?= htmlspecialchars($bulan) ?></h5>
                        
                        <?php foreach ($subkategori_data as $subkategori => $data): ?>
                            <div class="mb-3">
                                <h6 class="text-dark">
                                    <?= htmlspecialchars($subkategori) ?> 
                                    <small class="text-muted">(<?= htmlspecialchars($data['kategori']) ?>)</small>
                                </h6>
                                
                        <div class="table-responsive" style="overflow-x:auto;">
                            <table class="table table-bordered table-sm">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>No. Kwitansi</th>
                                        <th>Uraian</th>
                                        <th class="text-end">Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($data['transactions'] as $trans): ?>
                                        <tr>
                                            <td><?= date('d-m-Y', strtotime($trans['tanggal'])) ?></td>
                                            <td><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                                            <td><?= htmlspecialchars($trans['uraian']) ?></td>
                                            <td class="text-end">Rp <?= number_format($trans['jumlah'], 0, ',', '.') ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                                <tfoot>
                                    <tr class="table-info">
                                        <th colspan="3" class="text-end">Total</th>
                                        <th class="text-end fw-bold">Rp <?= number_format($data['total'], 0, ',', '.') ?></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <hr>
                <?php endforeach; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                <?php if ($search_keyword): ?>
                    Tidak ada data yang cocok dengan pencarian "<?= htmlspecialchars($search_keyword) ?>".
                <?php else: ?>
                    Tidak ada data laporan untuk filter yang dipilih.
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>


</div>
