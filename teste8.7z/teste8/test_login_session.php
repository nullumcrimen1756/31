<?php
require_once 'config.php';
require_once 'functions.php';

// Test the device detection function
$user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36";
$device_info = detectDeviceInfo($user_agent);

echo "Device Detection Test:\n";
print_r($device_info);

echo "\n\nTesting saveLoginLog function:\n";
// Test saving login log
$test_username = "testuser";
$result = saveLoginLog($test_username);

if ($result) {
    echo "Login log saved successfully!\n";
    
    // Test getting latest login info
    $latest_info = getLatestLoginInfo($test_username);
    if ($latest_info) {
        echo "\nLatest login info:\n";
        print_r($latest_info);
    } else {
        echo "No login info found\n";
    }
} else {
    echo "Failed to save login log\n";
    echo "Error: " . $conn->error . "\n";
}

// Test active sessions
echo "\n\nTesting getActiveSessions function:\n";
$active_sessions = getActiveSessions($test_username);
if (!empty($active_sessions)) {
    echo "Active sessions found: " . count($active_sessions) . "\n";
    foreach ($active_sessions as $session) {
        echo "- " . $session['waktu_login'] . " from " . $session['ip_address'] . "\n";
    }
} else {
    echo "No active sessions found\n";
}
?>
