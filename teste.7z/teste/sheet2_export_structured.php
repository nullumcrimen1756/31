<?php
session_start();

// Ambil parameter filter
$selected_jurnal_filter = isset($_GET['jurnal_filter']) ? $_GET['jurnal_filter'] : '';
$selected_tahun_filter = isset($_GET['tahun_filter']) ? $_GET['tahun_filter'] : date('Y');
$search_keyword = isset($_GET['search']) ? trim($_GET['search']) : '';

// Validasi session dan data
if (!isset($_SESSION['sheet2_report']) || empty($_SESSION['sheet2_report'])) {
    die("Tidak ada data laporan untuk diexport.");
}

$report = $_SESSION['sheet2_report'];
require_once 'config.php'; // Ambil $daftar_jurnal dari config.php
require_once 'includes/url_helper.php'; // Include URL helpers

// Filter data sesuai parameter

if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])) {
    $selected_jurnal_name = $daftar_jurnal[$selected_jurnal_filter];
    if (isset($report[$selected_jurnal_name])) {
        $report = [$selected_jurnal_name => $report[$selected_jurnal_name]];
    } else {
        $report = [];
    }
}

if (!empty($search_keyword)) {
    $filtered_report = [];
    foreach ($report as $jurnal => $bulan_data) {
        $filtered_bulan_data = [];
        foreach ($bulan_data as $bulan => $subkategori_data) {
            $filtered_subkategori_data = [];
            foreach ($subkategori_data as $subkategori => $data) {
                $filtered_transactions = [];
                foreach ($data['transactions'] as $trans) {
                    if (stripos($trans['no_kwitansi'], $search_keyword) !== false || stripos($trans['uraian'], $search_keyword) !== false) {
                        $filtered_transactions[] = $trans;
                    }
                }
                if (!empty($filtered_transactions)) {
                    $filtered_subkategori_data[$subkategori] = [
                        'kategori' => $data['kategori'],
                        'transactions' => $filtered_transactions,
                        'total' => array_sum(array_column($filtered_transactions, 'jumlah'))
                    ];
                }
            }
            if (!empty($filtered_subkategori_data)) {
                $filtered_bulan_data[$bulan] = $filtered_subkategori_data;
            }
        }
        if (!empty($filtered_bulan_data)) {
            $filtered_report[$jurnal] = $filtered_bulan_data;
        }
    }
    $report = $filtered_report;
}

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"Laporan_Terstruktur_" . date('Ymd_His') . ".xls\"");
header("Pragma: no-cache");
header("Expires: 0");

function indonesianDate($date) {
    return date('d-m-Y', strtotime($date));
}

// Fungsi untuk format angka yang kompatibel dengan Excel
function formatRupiahExport($number) {
    // Gunakan format tanpa pemisah untuk memastikan Excel membaca sebagai angka
    return number_format($number, 0, '', ''); // Format: 250000 (tanpa pemisah, Excel friendly)
}

// Fungsi alternatif tanpa pemisah (untuk memastikan Excel membaca sebagai angka)
function formatNumberExcel($number) {
    return number_format($number, 0, '', ''); // Format: 250000 (no separator)
}
?>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .title { font-size: 18pt; font-weight: bold; color: #1F4E78; margin-bottom: 5px; }
        .subtitle { font-size: 14pt; color: #2F75B5; margin-bottom: 15px; }
        .info-table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        .info-table td { padding: 5px; border: 1px solid #BFBFBF; }
        .info-label { font-weight: bold; background-color: #E6E6E6; width: 120px; }
        .month-section { margin-bottom: 30px; page-break-inside: avoid; }
        .month-title { font-size: 14pt; font-weight: bold; color: #548235; background-color: #E2EFDA; padding: 8px; border-left: 4px solid #548235; margin-bottom: 15px; }
        .subcategory-section { margin-bottom: 20px; }
        .subcategory-title { font-size: 12pt; font-weight: bold; color: #823535; background-color: #FCE4D6; padding: 6px; border-left: 3px solid #823535; margin-bottom: 10px; }
        .data-table { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
        .data-table th { background-color: #4472C4; color: white; font-weight: bold; padding: 8px; border: 1px solid #5B5B5B; text-align: center; }
        .data-table td { padding: 6px; border: 1px solid #BFBFBF; vertical-align: top; }
        .total-row { font-weight: bold; background-color: #D9E1F2; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .number-format { mso-number-format: "#\\.##0"; }
        .date-format { mso-number-format: "dd-mmm-yyyy"; }
        .footer { margin-top: 30px; font-style: italic; color: #7F7F7F; text-align: right; }
        /* Format angka untuk Excel */
        .number-cell { mso-number-format: "#\\.##0"; text-align: right; }
        /* Add horizontal scroll for tables */
        .data-table-wrapper {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="title">LAPORAN KEUANGAN TERSTRUKTUR</div>
        <div class="subtitle">SHEET 2 - PENGELOMPOKAN DATA</div>
    </div>

    <table class="info-table">
        <tr>
            <td class="info-label">Periode Laporan:</td>
            <td><?= date('d F Y', strtotime('first day of January '.$selected_tahun_filter)) ?> s/d <?= date('d F Y', strtotime('last day of December '.$selected_tahun_filter)) ?></td>
        </tr>
        <?php if ($selected_jurnal_filter && isset($daftar_jurnal[$selected_jurnal_filter])): ?>
        <tr>
            <td class="info-label">Jurnal:</td>
            <td><?= htmlspecialchars($daftar_jurnal[$selected_jurnal_filter]) ?></td>
        </tr>
        <?php endif; ?>
        <?php if ($search_keyword): ?>
        <tr>
            <td class="info-label">Kata Kunci Pencarian:</td>
            <td>"<?= htmlspecialchars($search_keyword) ?>"</td>
        </tr>
        <?php endif; ?>
        <tr>
            <td class="info-label">Tanggal Export:</td>
            <td><?= date('d-m-Y H:i:s') ?></td>
        </tr>
        <tr>
            <td class="info-label">Jumlah Data:</td>
            <td>
                <?php
                $total_transactions = 0;
                $total_amount = 0;
                foreach ($report as $jurnal => $bulan_data) {
                    foreach ($bulan_data as $bulan => $subkategori_data) {
                        foreach ($subkategori_data as $subkategori => $data) {
                            $total_transactions += count($data['transactions']);
                            $total_amount += $data['total'];
                        }
                    }
                }
                echo number_format($total_transactions, 0, ',', '') . ' transaksi';
                ?>
            </td>
        </tr>
        <tr>
            <td class="info-label">Total Nilai:</td>
            <td>Rp <?= number_format($total_amount, 0, ',', '') ?></td>
        </tr>
    </table>

    <?php if (!empty($report)): ?>
        <?php foreach ($report as $jurnal => $bulan_data): ?>
            <div style="font-size: 16pt; font-weight: bold; color: #2F75B5; margin: 25px 0 15px 0; padding-bottom: 5px; border-bottom: 2px solid #2F75B5;">
                JURNAL: <?= htmlspecialchars($jurnal) ?>
            </div>
            <?php
            $sorted_months = [];
            foreach ($bulan_data as $bulan => $subkategori_data) {
                $month_name = $bulan;
                $month_number = date('m', strtotime("1 $month_name"));
                $sorted_months[$month_number] = $bulan;
            }
            ksort($sorted_months);
            ?>
            <?php foreach ($sorted_months as $month_number => $bulan): ?>
                <?php $subkategori_data = $bulan_data[$bulan]; ?>
                <div class="month-section">
                    <div class="month-title"><?= strtoupper($bulan) ?></div>
                    <?php foreach ($subkategori_data as $subkategori => $data): ?>
                        <div class="subcategory-section">
                            <div class="subcategory-title">
                                <?= htmlspecialchars($subkategori) ?> 
                                <span style="font-weight: normal; font-style: italic;">(<?= htmlspecialchars($data['kategori']) ?>)</span>
                            </div>
                            <div class="data-table-wrapper">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th width="15%">Tanggal</th>
                                            <th width="20%">No. Kwitansi</th>
                                            <th width="40%">Uraian</th>
                                            <th width="15%">Kas</th>
                                            <th width="10%">Kode Subkategori</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($data['transactions'] as $trans): ?>
                                            <tr>
                                                <td class="text-center date-format"><?= indonesianDate($trans['tanggal']) ?></td>
                                                <td><?= htmlspecialchars($trans['no_kwitansi']) ?></td>
                                                <td><?= htmlspecialchars($trans['uraian']) ?></td>
                                                <td class="text-right number-format"><?= number_format($trans['jumlah'], 0, ',', '') ?></td>
                                                <td class="text-center"><?= htmlspecialchars($subkategori) ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                        <!-- Total row - aligned with Jumlah column -->
                                        <tr class="total-row">
                                            <td></td>
                                            <td></td>
                                            <td class="text-right">Total <?= htmlspecialchars($subkategori) ?>:</td>
                                            <td class="text-right number-format"><?= number_format($data['total'], 0, ',', '') ?></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <?php $month_total = 0; foreach ($subkategori_data as $data) { $month_total += $data['total']; } ?>
                    <div style="margin-top: 15px;">
                        <table style="width: 100%;">
                            <tr>
                                <td style="width: 70%; text-align: right; font-weight: bold; font-size: 11pt;">TOTAL <?= strtoupper($bulan) ?>:</td>
                                <td style="width: 15%; text-align: right; font-weight: bold; font-size: 11pt; border-top: 2px solid #5B5B5B; border-bottom: 2px double #5B5B5极速飞艇开奖结果记录;" class="number-format"><?= number_format($month_total, 0, ',', '') ?></td>
                                <td style="width: 15%;"></td>
                            </tr>
                        </table>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endforeach; ?>
        <div style="margin-top: 30px; page-break-before: avoid;">
            <table style="width: 100%;">
                <tr>
                    <td style="width: 70%; text-align: right; font-weight: bold; font-size: 12pt; color: #C55A11;">TOTAL KESELURUHAN:</td>
                    <td style="width: 15%; text-align: right; font-weight: bold; font-size: 12pt; color: #C55A11; border-top: 2px solid #C55A11; border-bottom: 3px double #C55A11;" class="number-format"><?= number_format($total_amount, 0, ',', '') ?></td>
                    <td style="width: 15%;"></td>
                </tr>
            </table>
        </div>
    <?php else: ?>
        <div style="color: #FF0000; font-weight: bold; font-style: italic; text-align: center; margin: 30px 0;">Tidak ada data yang cocok dengan filter yang dipilih.</div>
    <?php endif; ?>

    <div class="footer">Dokumen ini dihasilkan secara otomatis pada <?= date('d F Y H:i:s') ?> dari Sistem Laporan Keuangan</div>
</body>
</html>


