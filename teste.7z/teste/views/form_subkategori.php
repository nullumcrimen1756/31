<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Subkategori</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
        }
        
        .card-form {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: none;
        }
        
        .form-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .btn-submit {
            background-color: var(--secondary-color);
            border: none;
        }
        
        .btn-submit:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card card-form">
                    <div class="card-header form-header">
                        <h4 class="mb-0"><i class="bi bi-tags me-2"></i>Form Tambah Subkategori</h4>
                    </div>
                    
                    <div class="card-body">
                        <?php if (isset($_SESSION['error'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <form action="admin_kategori.php?action=save_subkategori<?php echo $selected_jurnal_id ? '&id_jurnal='.$selected_jurnal_id : ''; ?>" method="post">
                        <div class="mb-3">
                            <label for="id_kategori" class="form-label">Kategori Induk</label>
                            <select id="id_kategori" name="id_kategori" class="form-select" required>
                                <option value="" selected disabled>Pilih Kategori</option>
                                <?php foreach ($kategori as $kat): ?>
                                    <option value="<?php echo $kat['id_kategori']; ?>">
                                        <?php echo htmlspecialchars($kat['kode_kategori'] . ' - ' . $kat['nama_kategori']); ?>
                                        (<?php 
                                            foreach ($jurnals as $jurnal) {
                                                if ($jurnal['id_jurnal'] == $kat['id_jurnal']) {
                                                    echo htmlspecialchars($jurnal['nama_jurnal']);
                                                    break;
                                                }
                                            }
                                        ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                            
                            <div class="mb-3">
                                <label for="kode_subkategori" class="form-label">
                                    Kode Subkategori <span class="text-danger">*</span>
                                </label>
                                <input type="text" 
                                       class="form-control" 
                                       id="kode_subkategori" 
                                       name="kode_subkategori" 
                                       placeholder="Contoh: 100.01 atau 200.02.3a" 
                                       pattern="[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3}[a-zA-Z]?)?" 
                                       title="Format: xxx.xx atau xxx.xx.xx[a-z] (level 1-2 angka, level 3 angka dengan huruf opsional di akhir)"
                                       required>
                                <div class="form-text">
                                    <i class="bi bi-info-circle me-1"></i>
                                    <strong>Struktur Hierarki:</strong>
                                    <br>
                                    <small class="text-muted">
                                        • <strong>Level 1:</strong> <kode kategori>.<kode sub-1> (contoh: <strong>100.01</strong>)<br>
                                        • <strong>Level 2:</strong> <kode kategori>.<kode sub-1>.<kode sub-2> (contoh: <strong>100.01.ABC</strong>)<br>
                                        • <strong>Aturan:</strong> 3 digit awal + 2 digit setelah titik + opsional 2-3 karakter (angka/huruf)
                                    </small>
                                    <br><br>
                                    <strong>Contoh Valid:</strong>
                                    <br>
                                    <small class="text-success">
                                        • <strong>100.01</strong> = ATK (2 level)<br>
                                        • <strong>100.01.01a</strong> = Kertas (3 level angka dengan huruf di akhir)<br>
                                        • <strong>200.02.3a</strong> = Bantuan Pendidikan (3 level angka dengan huruf di akhir)<br>
                                        • <strong>300.10.01c</strong> = Kegiatan (3 level angka dengan huruf di akhir)
                                    </small>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="nama_subkategori" class="form-label">Nama Subkategori</label>
                                <input type="text" id="nama_subkategori" name="nama_subkategori" class="form-control" required>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="admin_kategori.php<?php echo isset($_GET['id_jurnal']) ? '?id_jurnal='.$_GET['id_jurnal'] : ''; ?>" 
                                   class="btn btn-outline-secondary me-md-2">
                                    <i class="bi bi-arrow-left me-1"></i> Kembali
                                </a>
                                <button type="submit" class="btn btn-submit text-white">
                                    <i class="bi bi-save me-1"></i> Simpan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>