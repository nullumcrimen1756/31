<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Transaksi Gereja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-bg: #f8f9fa;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--light-bg);
        }
        
        .card-form {
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: none;
        }
        
        .form-header {
            background-color: var(--primary-color);
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .form-label {
            font-weight: 600;
            color: var(--primary-color);
        }
        
        .form-control, .form-select {
            border-radius: 6px;
            padding: 10px 15px;
            border: 1px solid #ced4da;
            transition: all 0.3s;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        .btn-submit {
            background-color: var(--secondary-color) !important;
            color: white !important;
            border: none !important;
            padding: 10px 20px !important;
            font-weight: 600 !important;
            transition: all 0.3s !important;
            display: inline-block !important;
            visibility: visible !important;
            opacity: 1 !important;
        }
        
        .btn-submit:hover {
            background-color: #2980b9;
            transform: translateY(-2px);
        }
        
        .nav-pills .nav-link.active {
            background-color: var(--primary-color);
        }
        
        .nav-pills .nav-link {
            color: var(--primary-color);
        }
        
        .transaction-type {
            border-left: 4px solid var(--secondary-color);
            background-color: rgba(52, 152, 219, 0.1);
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 0 6px 6px 0;
        }
        
        .amount-input {
            position: relative;
        }
        
        .amount-input span {
            position: absolute;
            left: 15px;
            top: 38px; /* Posisi yang lebih tepat */
            font-weight: 600;
            color: var(--primary-color);
            line-height: 1.5;
        }
        
        .amount-input input {
            padding-left: 40px !important;
        }
        
        .error-message {
            color: var(--accent-color);
            font-size: 0.9rem;
            margin-top: 5px;
        }

        .text-end {
            text-align: right !important;
        }
        
        /* Tambahan untuk form validation */
        .form-control:invalid {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 0.25rem rgba(231, 76, 60, 0.25);
        }
        
        .form-control:valid {
            border-color: #28a745;
            border-width: 2px;
            box-shadow: 0 0 0 0.25rem rgba(40, 167, 69, 0.25);
        }
        
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            line-height: 1.4;
        }
        
        .form-text i {
            color: var(--secondary-color);
        }
        
        .form-text strong {
            color: var(--primary-color);
        }
        
        .form-text .text-muted {
            color: #6c757d !important;
        }
        
        .form-text .text-success {
            color: #28a745 !important;
        }
        
        /* Styling untuk input yang sedang difokuskan */
        .form-control:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 0 0.25rem rgba(52, 152, 219, 0.25);
        }
        
        /* Styling untuk placeholder */
        .form-control::placeholder {
            color: #adb5bd;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card card-form">
                    <div class="card-header form-header">
                        <h4 class="mb-0"><i class="bi bi-journal-plus me-2"></i>Form Input Transaksi</h4>
                    </div>
                    
                    <div class="card-body">
                        <?php if (isset($_SESSION['success'])): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if (isset($_SESSION['errors'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <h5 class="alert-heading">Terjadi Kesalahan!</h5>
                                <ul class="mb-0">
                                    <?php foreach ($_SESSION['errors'] as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                                <?php unset($_SESSION['errors']); ?>
                            </div>
                        <?php endif; ?>
                        
                        <ul class="nav nav-pills mb-4">
                            <li class="nav-item">
                                <a class="nav-link" href="<?= url('index.php') ?>"><i class="bi bi-house-door me-1"></i> Beranda</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= page_url('index.php', ['action' => 'sheet1_report']) ?>"><i class="bi bi-table me-1"></i> Sheet 1 Report</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= page_url('index.php', ['action' => 'sheet2_report']) ?>"><i class="bi bi-list-check me-1"></i> Sheet 2 Report</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?= page_url('index.php', ['action' => 'sheet3_report']) ?>"><i class="bi bi-graph-up me-1"></i> Sheet 3 Report</a>
                            </li>
                        </ul>
                        
                        <form action="index.php?action=submit" method="post" id="transaksiForm">
                            <div class="transaction-type">
                                <h5 class="fw-bold text-primary mb-3"><i class="bi bi-journal-text me-2"></i>Jenis Transaksi</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="id_jurnal" class="form-label">Jurnal</label>
                                        <select id="id_jurnal" name="id_jurnal" class="form-select" required>
                                            <option value="" selected disabled>Pilih Jurnal</option>
                                            <?php foreach ($jurnal as $jur): ?>
                                                <option value="<?php echo $jur['id_jurnal']; ?>">
                                                    <?php echo $jur['nama_jurnal']; ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="tanggal" class="form-label">Tanggal Transaksi</label>
                                        <input type="date" id="tanggal" name="tanggal" class="form-control" 
                                               value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h5 class="fw-bold text-primary mb-3"><i class="bi bi-card-text me-2"></i>Detail Transaksi</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="no_kwitansi" class="form-label">Nomor Kwitansi</label>
                                        <input type="text" id="no_kwitansi" name="no_kwitansi" class="form-control" 
                                               placeholder="Masukkan nomor kwitansi" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="id_kategori" class="form-label">Kategori</label>
                                        <select id="id_kategori" name="id_kategori" class="form-select" required disabled>
                                            <option value="" selected disabled>Pilih jurnal terlebih dahulu</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="id_subkategori" class="form-label">Sub Kategori</label>
                                        <select id="id_subkategori" name="id_subkategori" class="form-select" required disabled>
                                            <option value="" selected disabled>Pilih kategori terlebih dahulu</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3 amount-input">
                                        <label for="jumlah" class="form-label">Jumlah</label>
                                        <span>Rp</span>
                                        <input type="number" id="jumlah" name="jumlah" class="form-control" 
                                               min="0" step="0.01" value="0" placeholder="0,00" required>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="uraian" class="form-label">Uraian/Keterangan</label>
                                    <textarea id="uraian" name="uraian" class="form-control" rows="3" 
                                              placeholder="Deskripsi transaksi" required></textarea>
                                </div>
                                
                                <div class="mb-3 amount-input">
                                    <label for="setoran" class="form-label">Setoran (Opsional)</label>
                                    <span>Rp</span>
                                    <input type="number" id="setoran" name="setoran" class="form-control" 
                                           min="0" step="0.01" value="0" placeholder="0,00">
                                </div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="reset" class="btn btn-outline-secondary me-md-2">
                                    <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
                                </button>
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="bi bi-save me-1"></i> Simpan Transaksi
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Fungsi untuk memuat kategori berdasarkan jurnal
        document.getElementById('id_jurnal').addEventListener('change', function() {
            const jurnalId = this.value;
            const kategoriSelect = document.getElementById('id_kategori');
            
            if (jurnalId) {
                fetch(`index.php?action=get_kategori&id_jurnal=${jurnalId}`)
                    .then(response => response.json())
                    .then(data => {
                        kategoriSelect.innerHTML = '';
                        
                        if (data.length > 0) {
                            kategoriSelect.disabled = false;
                            const defaultOption = document.createElement('option');
                            defaultOption.value = '';
                            defaultOption.textContent = 'Pilih Kategori';
                            defaultOption.selected = true;
                            defaultOption.disabled = true;
                            kategoriSelect.appendChild(defaultOption);
                            
                            data.forEach(kat => {
                                const option = document.createElement('option');
                                option.value = kat.id_kategori;
                                option.textContent = `${kat.kode_kategori} - ${kat.nama_kategori}`;
                                kategoriSelect.appendChild(option);
                            });
                        } else {
                            kategoriSelect.disabled = true;
                            const option = document.createElement('option');
                            option.textContent = 'Tidak ada kategori tersedia';
                            option.disabled = true;
                            kategoriSelect.appendChild(option);
                        }
                        
                        // Reset subkategori
                        const subkategoriSelect = document.getElementById('id_subkategori');
                        subkategoriSelect.innerHTML = '';
                        subkategoriSelect.disabled = true;
                        const subOption = document.createElement('option');
                        subOption.textContent = 'Pilih kategori terlebih dahulu';
                        subOption.disabled = true;
                        subOption.selected = true;
                        subkategoriSelect.appendChild(subOption);
                    });
            } else {
                kategoriSelect.innerHTML = '';
                kategoriSelect.disabled = true;
                const option = document.createElement('option');
                option.textContent = 'Pilih jurnal terlebih dahulu';
                option.disabled = true;
                option.selected = true;
                kategoriSelect.appendChild(option);
                
                // Reset subkategori
                const subkategoriSelect = document.getElementById('id_subkategori');
                subkategoriSelect.innerHTML = '';
                subkategoriSelect.disabled = true;
                const subOption = document.createElement('option');
                subOption.textContent = 'Pilih kategori terlebih dahulu';
                subOption.disabled = true;
                subOption.selected = true;
                subkategoriSelect.appendChild(subOption);
            }
        });
        
        // Fungsi untuk memuat subkategori berdasarkan kategori
        document.getElementById('id_kategori').addEventListener('change', function() {
            const kategoriId = this.value;
            const subkategoriSelect = document.getElementById('id_subkategori');
            
            if (kategoriId) {
                const url = `index.php?action=get_subkategori&id_kategori=${kategoriId}`;
                
                fetch(url)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(data => {
                        
                        subkategoriSelect.innerHTML = '';
                        
                        if (data.length > 0) {
                            subkategoriSelect.disabled = false;
                            const defaultOption = document.createElement('option');
                            defaultOption.value = '';
                            defaultOption.textContent = 'Pilih Subkategori';
                            defaultOption.selected = true;
                            defaultOption.disabled = true;
                            subkategoriSelect.appendChild(defaultOption);
                            
                            data.forEach(sub => {
                                const option = document.createElement('option');
                                option.value = sub.id_subkategori;
                                
                                // Handle both simple and complex code formats
                                const displayCode = formatSubkategoriCode(sub.kode_subkategori);
                                option.textContent = `${displayCode} - ${sub.nama_subkategori}`;
                                subkategoriSelect.appendChild(option);
                            });
                        } else {
                            subkategoriSelect.disabled = true;
                            const option = document.createElement('option');
                            option.textContent = 'Tidak ada subkategori tersedia';
                            option.disabled = true;
                            subkategoriSelect.appendChild(option);
                        }
                    })
                    .catch(error => {
                        console.error('❌ Error fetching subkategori:', error); // Debug log
                        // Tampilkan error ke user
                        subkategoriSelect.innerHTML = '';
                        subkategoriSelect.disabled = true;
                        const option = document.createElement('option');
                        option.textContent = 'Error: ' + error.message;
                        option.disabled = true;
                        subkategoriSelect.appendChild(option);
                    });
            } else {
                subkategoriSelect.innerHTML = '';
                subkategoriSelect.disabled = true;
                const option = document.createElement('option');
                option.textContent = 'Pilih kategori terlebih dahulu';
                option.disabled = true;
                option.selected = true;
                subkategoriSelect.appendChild(option);
            }
        });
        
        // Auto-fill uraian berdasarkan subkategori yang dipilih
        document.getElementById('id_subkategori').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            if (selectedOption.textContent.includes('-')) {
                const uraian = selectedOption.textContent.split('-')[1].trim();
                document.getElementById('uraian').value = uraian;
            }
        });
        
        // Format input jumlah saat kehilangan fokus
        document.getElementById('jumlah').addEventListener('blur', function() {
            this.value = parseFloat(this.value || 0).toFixed(2);
        });
        
        // Format input setoran saat kehilangan fokus
        document.getElementById('setoran').addEventListener('blur', function() {
            this.value = parseFloat(this.value || 0).toFixed(2);
        });

        // Fungsi untuk memformat kode subkategori agar mudah dibaca
        function formatSubkategoriCode(code) {
            if (!code) return '';
            
            // Jika kode sudah dalam format yang benar, kembalikan as is
            if (code.includes('.')) {
                return code;
            }
            
            // Jika kode adalah angka 3 digit, tambahkan .00
            if (/^[0-9]{3}$/.test(code)) {
                return code + '.00';
            }
            
            return code;
        }

        // Fungsi untuk validasi format kode subkategori
        function validateSubkategoriCode(code) {
            // Format: xxx.xx.xx atau xxx.xx.xxx
            const pattern = /^[0-9]{3}\.[0-9]{2}(\.[0-9]{2,3})?$/;
            return pattern.test(code);
        }

        // Event listener untuk validasi real-time pada input kode subkategori
        document.addEventListener('DOMContentLoaded', function() {
            const subkategoriInput = document.getElementById('kode_subkategori');
            if (subkategoriInput) {
                subkategoriInput.addEventListener('input', function() {
                    const code = this.value;
                    if (code && !validateSubkategoriCode(code)) {
                        this.setCustomValidity('Format tidak valid. Gunakan: xxx.xx.xx atau xxx.xx.xxx');
                        this.classList.add('is-invalid');
                    } else {
                        this.setCustomValidity('');
                        this.classList.remove('is-invalid');
                        this.classList.add('is-valid');
                    }
                });
            }
        });

        document.getElementById('transaksiForm').addEventListener('submit', function() {
            const kat = document.getElementById('id_kategori');
            const sub = document.getElementById('id_subkategori');
            if (kat && kat.disabled && kat.value) kat.disabled = false;
            if (sub && sub.disabled && sub.value) sub.disabled = false;
        });


    </script>
</body>
</html>